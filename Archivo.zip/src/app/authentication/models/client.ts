export class Client {
    idClients: number;
    name: string;
}
