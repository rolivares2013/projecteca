export class User {
    id: string;
    password: string;
    clientid:number;
}
