import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-not-found',
  templateUrl: './not-found.component.html'
})
export class NotfoundComponent implements AfterViewInit {
  ngAfterViewInit() {}
}
