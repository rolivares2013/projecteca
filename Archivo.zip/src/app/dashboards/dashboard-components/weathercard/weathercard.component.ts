import { Component } from '@angular/core';
@Component({
  selector: 'app-weather',
  templateUrl: './weathercard.component.html'
})
export class WeathercardComponent {
  constructor() {}
}
