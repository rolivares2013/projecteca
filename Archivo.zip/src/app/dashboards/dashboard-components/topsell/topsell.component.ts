import { Component } from '@angular/core';
@Component({
  selector: 'app-topsell',
  templateUrl: './topsell.component.html'
})
export class TopsellComponent {
  constructor() {}
}
