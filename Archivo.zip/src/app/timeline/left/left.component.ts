import { Component } from '@angular/core';

@Component({
  templateUrl: 'left.component.html'
})
export class LeftComponent {}
