import { Component } from '@angular/core';

@Component({
  selector: 'app-form-striped',
  templateUrl: './striped.component.html',
  styleUrls: ['./striped.component.css']
})
export class FormstripedComponent {}
