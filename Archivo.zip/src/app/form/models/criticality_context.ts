export class Lh_has_clsContext {
    TitleContext:string;
    DescriptionContext:string;
}

