
export class Participant_has_workshop {
    ParticipantId: number;
    WorkshopId: number;
    assitance:number;
}

