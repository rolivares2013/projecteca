export class Lh_has_cl {
    
    WorkshopId: number;
    EquipmentId: number;
    TitleContext: string;
    DescriptionContext: string;
    CriticalityComment: string;

}

