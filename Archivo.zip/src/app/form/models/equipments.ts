export class Equipment {
    id: number;
    functionalLocation:string;
    functionalLocationsDescription:string;
    idTagNumber: string;
    centerCost:string;
}

