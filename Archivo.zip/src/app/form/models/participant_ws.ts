export class Participant_ws {
    Workshop_idWorkshop: number;
}

