export class Project {
    id: number;
    nameProject:string;
    functionalLoc:Date;
}

