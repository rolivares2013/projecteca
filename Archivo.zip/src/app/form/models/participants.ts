export class Participant {
    id: number;
    name:string;
    run:string;
    email: string;
    mobile:string;
    RoleId: number;
    DicipleneId: number;
    PositionId: number;
}
