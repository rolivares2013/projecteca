export class Workshop {
    id: number;
    nameWorkshop:string;
    dateRealization:Date;
    ProjectId: number;
    Projects_idProjects:number;
    dateEnd:Date;
    comentary:string;
}

