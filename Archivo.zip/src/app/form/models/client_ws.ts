export class Client_ws {
    ClientIdX: number;
}

