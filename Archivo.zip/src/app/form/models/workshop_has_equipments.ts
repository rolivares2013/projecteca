export class Workshop_has_equipments {
    WorkshopId: number;
    EquipmentId: number;
}

