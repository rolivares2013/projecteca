import { Component } from '@angular/core';

@Component({
  templateUrl: 'custom.component.html'
})
export class CustomComponent {}
