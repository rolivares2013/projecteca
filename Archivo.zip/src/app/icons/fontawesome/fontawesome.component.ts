import { Component } from '@angular/core';
@Component({
  templateUrl: 'fontawesome.component.html'
})
export class FontawesomeComponent {}
